import { useEffect, useState } from "react";
import axios from "axios";
import TareaForm from "./components/TareaForm";
import TareaList from "./components/TareaList";

const API = import.meta.env.VITE_API_URL;

function App() {
  const [tareas, setTareas] = useState([]);

  const cargarTareas = async () => {
    const res = await axios.get(API);
    setTareas(res.data);
  };

  useEffect(() => {
    cargarTareas();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Gestor de Tareas</h1>
        <TareaForm onAdd={cargarTareas} />
        <TareaList tareas={tareas} onReload={cargarTareas} />
      </div>
    </div>
  );
}

export default App;
