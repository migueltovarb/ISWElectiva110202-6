import axios from "axios";
import { useState } from "react";

const API = import.meta.env.VITE_API_URL;

export default function TareaList({ tareas, onReload }) {
  const [editandoId, setEditandoId] = useState(null);
  const [nuevoTitulo, setNuevoTitulo] = useState("");
  const [nuevaDescripcion, setNuevaDescripcion] = useState("");
  const [nuevoEstado, setNuevoEstado] = useState("");

  const iniciarEdicion = (tarea) => {
    setEditandoId(tarea.id);
    setNuevoTitulo(tarea.titulo);
    setNuevaDescripcion(tarea.descripcion || "");
    setNuevoEstado(tarea.estado);
  };

  const cancelarEdicion = () => {
    setEditandoId(null);
    setNuevoTitulo("");
    setNuevaDescripcion("");
    setNuevoEstado("");
  };

  const guardarEdicion = async (tarea) => {
    await axios.put(`${API}${tarea.id}/`, {
      titulo: nuevoTitulo,
      descripcion: nuevaDescripcion,
      estado: nuevoEstado,
    });
    cancelarEdicion();
    onReload();
  };

  const eliminarTarea = async (id) => {
    await axios.delete(`${API}${id}/`);
    onReload();
  };

  if (tareas.length === 0)
    return <p className="text-center text-gray-500">No hay tareas registradas.</p>;

  return (
    <ul className="space-y-3">
      {tareas.map((tarea) => (
        <li
          key={tarea.id}
          className={`p-4 rounded shadow ${
            tarea.estado === "hecha"
              ? "bg-green-100"
              : tarea.estado === "en_progreso"
              ? "bg-yellow-100"
              : tarea.estado === "cancelada"
              ? "bg-red-100"
              : "bg-white"
          }`}
        >
          {editandoId === tarea.id ? (
            <div className="space-y-2">
              <input
                type="text"
                className="w-full border rounded px-3 py-1"
                value={nuevoTitulo}
                onChange={(e) => setNuevoTitulo(e.target.value)}
              />
              <textarea
                className="w-full border rounded px-3 py-1"
                rows="3"
                value={nuevaDescripcion}
                onChange={(e) => setNuevaDescripcion(e.target.value)}
              />
              <select
                className="w-full border rounded px-3 py-1"
                value={nuevoEstado}
                onChange={(e) => setNuevoEstado(e.target.value)}
              >
                <option value="pendiente">Pendiente</option>
                <option value="en_progreso">En progreso</option>
                <option value="hecha">Hecha</option>
                <option value="cancelada">Cancelada</option>
              </select>
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => guardarEdicion(tarea)}
                  className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                >
                  💾 Guardar
                </button>
                <button
                  onClick={cancelarEdicion}
                  className="bg-gray-400 text-white px-3 py-1 rounded hover:bg-gray-500"
                >
                  Cancelar
                </button>
              </div>
            </div>
          ) : (
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold">{tarea.titulo}</p>
                {tarea.descripcion && (
                  <p className="text-sm text-gray-700 mt-1">{tarea.descripcion}</p>
                )}
                <p className="text-sm text-gray-500 mt-1 italic">
                  Estado: {tarea.estado.replace("_", " ")}
                </p>
              </div>
              <div className="flex flex-col gap-2 ml-4">
                <button
                  onClick={() => iniciarEdicion(tarea)}
                  className="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
                >
                  ✏️ Editar
                </button>
                <button
                  onClick={() => eliminarTarea(tarea.id)}
                  className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700"
                >
                  🗑 Eliminar
                </button>
              </div>
            </div>
          )}
        </li>
      ))}
    </ul>
  );
}
