import { useState } from "react";
import axios from "axios";

const API = import.meta.env.VITE_API_URL;

export default function TareaForm({ onAdd }) {
  const [titulo, setTitulo] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [estado, setEstado] = useState("pendiente");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!titulo.trim()) return;
    await axios.post(API, {
      titulo,
      descripcion,
      estado,
    });
    setTitulo("");
    setDescripcion("");
    setEstado("pendiente");
    onAdd();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mb-6">
      <input
        type="text"
        placeholder="Título de la tarea"
        value={titulo}
        onChange={(e) => setTitulo(e.target.value)}
        className="w-full border border-gray-300 rounded px-3 py-2"
      />
      <textarea
        placeholder="Descripción"
        rows="3"
        value={descripcion}
        onChange={(e) => setDescripcion(e.target.value)}
        className="w-full border border-gray-300 rounded px-3 py-2"
      />
      <select
        value={estado}
        onChange={(e) => setEstado(e.target.value)}
        className="w-full border border-gray-300 rounded px-3 py-2"
      >
        <option value="pendiente">Pendiente</option>
        <option value="en_progreso">En progreso</option>
        <option value="hecha">Hecha</option>
        <option value="cancelada">Cancelada</option>
      </select>
      <button className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        Agregar Tarea
      </button>
    </form>
  );
}
